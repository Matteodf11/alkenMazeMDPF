/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pedro.ieslaencanta.com.falkensmaze.components;

/**
 *
 * @author Pedro
 */

//Interfaz para escuchar los eventos al hacer click o doble click en un bloque
public interface IBlockListener {
    public void onClicked(Block b);
    public void onDoubleClicked(Block b);
}
